package androidx.cardview;

import com.p007az.portal.R;

/* renamed from: androidx.cardview.R */
public final class C0117R {

    /* renamed from: androidx.cardview.R$attr */
    public static final class attr {
        public static final int cardBackgroundColor = 2130772258;
        public static final int cardCornerRadius = 2130772259;
        public static final int cardElevation = 2130772260;
        public static final int cardMaxElevation = 2130772261;
        public static final int cardPreventCornerOverlap = 2130772263;
        public static final int cardUseCompatPadding = 2130772262;
        public static final int cardViewStyle = 2130771974;
        public static final int contentPadding = 2130772264;
        public static final int contentPaddingBottom = 2130772268;
        public static final int contentPaddingLeft = 2130772265;
        public static final int contentPaddingRight = 2130772266;
        public static final int contentPaddingTop = 2130772267;
    }

    /* renamed from: androidx.cardview.R$color */
    public static final class color {
        public static final int cardview_dark_background = 2131623959;
        public static final int cardview_light_background = 2131623960;
        public static final int cardview_shadow_end_color = 2131623961;
        public static final int cardview_shadow_start_color = 2131623962;
    }

    /* renamed from: androidx.cardview.R$dimen */
    public static final class dimen {
        public static final int cardview_compat_inset_shadow = 2131361881;
        public static final int cardview_default_elevation = 2131361882;
        public static final int cardview_default_radius = 2131361883;
    }

    /* renamed from: androidx.cardview.R$style */
    public static final class C0118style {
        public static final int Base_CardView = 2131427494;
        public static final int CardView = 2131427468;
        public static final int CardView_Dark = 2131427572;
        public static final int CardView_Light = 2131427573;
    }

    /* renamed from: androidx.cardview.R$styleable */
    public static final class styleable {
        public static final int[] CardView = {16843071, 16843072, R.attr.cardBackgroundColor, R.attr.cardCornerRadius, R.attr.cardElevation, R.attr.cardMaxElevation, R.attr.cardUseCompatPadding, R.attr.cardPreventCornerOverlap, R.attr.contentPadding, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingTop, R.attr.contentPaddingBottom};
        public static final int CardView_android_minHeight = 1;
        public static final int CardView_android_minWidth = 0;
        public static final int CardView_cardBackgroundColor = 2;
        public static final int CardView_cardCornerRadius = 3;
        public static final int CardView_cardElevation = 4;
        public static final int CardView_cardMaxElevation = 5;
        public static final int CardView_cardPreventCornerOverlap = 7;
        public static final int CardView_cardUseCompatPadding = 6;
        public static final int CardView_contentPadding = 8;
        public static final int CardView_contentPaddingBottom = 12;
        public static final int CardView_contentPaddingLeft = 9;
        public static final int CardView_contentPaddingRight = 10;
        public static final int CardView_contentPaddingTop = 11;
    }
}
