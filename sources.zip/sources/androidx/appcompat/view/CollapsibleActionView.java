package androidx.appcompat.view;

public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
