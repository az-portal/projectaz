package androidx.cursoradapter;

/* renamed from: androidx.cursoradapter.R */
public final class C0180R {
}
