package androidx.arch.core;

/* renamed from: androidx.arch.core.R */
public final class C0089R {
}
