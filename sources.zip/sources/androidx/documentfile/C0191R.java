package androidx.documentfile;

/* renamed from: androidx.documentfile.R */
public final class C0191R {
}
