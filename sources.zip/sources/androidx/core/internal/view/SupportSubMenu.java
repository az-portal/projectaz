package androidx.core.internal.view;

import android.view.SubMenu;

public interface SupportSubMenu extends SupportMenu, SubMenu {
}
